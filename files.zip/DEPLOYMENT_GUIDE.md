# Deployment Guide: Water Intake Tracker to Vercel

## Quick Summary
This guide walks you through deploying your water intake tracker to Vercel using GitHub integration.

---

## Step-by-Step Instructions

### Step 1: Organize Files on GitHub

In your GitHub repository (hmgng2hzdd-cpu/Website), create this structure:

```
Website/
├── app/
│   ├── page.js          (rename from app-page.js)
│   ├── layout.js        (rename from app-layout.js)
│   └── globals.css
├── components/
│   └── WaterTracker.jsx  (rename from water-tracker.jsx)
├── public/
│   └── favicon.ico       (optional)
├── .gitignore
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── next.config.js
└── README.md
```

### Step 2: Upload Files to GitHub

1. **Option A - Using Git Command Line:**
```bash
# Navigate to your repository folder
cd path/to/Website

# Add all files
git add .

# Commit changes
git commit -m "Add water intake tracker application"

# Push to GitHub
git push origin main
```

2. **Option B - Using GitHub Web Interface:**
   - Go to https://github.com/hmgng2hzdd-cpu/Website
   - Click "Add file" → "Create new file"
   - Create each file with the structure above
   - Fill in content
   - Click "Commit changes"

### Step 3: Deploy to Vercel

Since you already have Vercel connected:

1. **Go to Vercel Dashboard:**
   - Visit https://vercel.com/dashboard
   - Sign in with your GitHub account

2. **Create New Project:**
   - Click "Add New..." → "Project"
   - Select "hmgng2hzdd-cpu/Website" repository
   - Click "Import"

3. **Configure Project:**
   - **Project Name**: water-intake-tracker (or your choice)
   - **Framework Preset**: Next.js (should auto-detect)
   - **Root Directory**: ./ (or . depending on where files are)
   - Keep other settings default

4. **Environment Variables:**
   - You don't need any for this project
   - Click "Deploy"

5. **Wait for Deployment:**
   - Vercel will build and deploy automatically
   - You'll see a URL like: `https://water-intake-tracker.vercel.app`

### Step 4: Verify Deployment

1. Click the deployment URL
2. You should see the water tracker app
3. Test functionality:
   - Click "Add 250ml" button
   - Progress circle should update
   - Refresh page - data should persist
   - Add custom amount and verify

---

## File Checklist

Before pushing to GitHub, verify you have these files:

- [ ] `app/page.js`
- [ ] `app/layout.js`
- [ ] `app/globals.css`
- [ ] `components/WaterTracker.jsx`
- [ ] `package.json`
- [ ] `tailwind.config.js`
- [ ] `postcss.config.js`
- [ ] `next.config.js`
- [ ] `.gitignore`
- [ ] `README.md`

---

## Automatic Deployments

Once your GitHub repo is connected to Vercel:

✅ **Every time you push to `main` branch:**
- Vercel automatically builds and deploys
- You get a preview URL for each push
- Production site updates when changes are merged to main

---

## Custom Domain (Optional)

To use your own domain:

1. In Vercel Dashboard, go to your project
2. Click "Settings" → "Domains"
3. Add your custom domain
4. Follow DNS configuration instructions
5. Done! Your app will be at your custom domain

---

## Troubleshooting

### Build Fails with "Module not found"
**Solution**: Make sure all dependencies are listed in `package.json`

### Page shows blank or 404
**Solution**: Verify file structure and that `app/page.js` exists at root level

### Styles not loading
**Solution**: Ensure Tailwind CSS is properly installed and `globals.css` is imported in layout

### Data not persisting
**Solution**: Browser localStorage works locally but check browser privacy settings

---

## Monitoring Your Deployment

After deployment, monitor from Vercel Dashboard:

1. **Analytics**: See traffic and performance
2. **Logs**: Check build and runtime logs
3. **Deployments**: View history of all deployments
4. **Environment Variables**: Add secrets if needed later

---

## Making Updates

After your initial deployment:

1. Edit files locally or on GitHub
2. Commit and push to main branch:
   ```bash
   git add .
   git commit -m "Update: [describe changes]"
   git push origin main
   ```
3. Vercel automatically redeploys within seconds

---

## Success! 🎉

Your water intake tracker is now live on Vercel!

**Share your app URL**: `https://your-deployment.vercel.app`

---

## Need Help?

- **Vercel Docs**: https://vercel.com/docs
- **Next.js Docs**: https://nextjs.org/docs
- **GitHub Issues**: Create an issue in your repository
