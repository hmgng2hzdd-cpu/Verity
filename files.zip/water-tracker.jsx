import React, { useState, useEffect } from 'react';
import { Droplet, Plus, Minus, RotateCcw } from 'lucide-react';

export default function WaterTracker() {
  const DAILY_GOAL = 2000; // 2 liters in ml
  const [waterIntake, setWaterIntake] = useState(0);
  const [entries, setEntries] = useState([]);
  const [customAmount, setCustomAmount] = useState('');

  // Load data from localStorage on mount
  useEffect(() => {
    const today = new Date().toDateString();
    const stored = localStorage.getItem('waterTracker');
    
    if (stored) {
      const data = JSON.parse(stored);
      if (data.date === today) {
        setWaterIntake(data.intake);
        setEntries(data.entries);
      } else {
        // Reset for new day
        localStorage.setItem('waterTracker', JSON.stringify({
          date: today,
          intake: 0,
          entries: []
        }));
      }
    } else {
      localStorage.setItem('waterTracker', JSON.stringify({
        date: today,
        intake: 0,
        entries: []
      }));
    }
  }, []);

  // Save to localStorage whenever intake changes
  const saveData = (newIntake, newEntries) => {
    const today = new Date().toDateString();
    localStorage.setItem('waterTracker', JSON.stringify({
      date: today,
      intake: newIntake,
      entries: newEntries
    }));
  };

  const addWater = (amount) => {
    const newIntake = waterIntake + amount;
    const newEntry = {
      id: Date.now(),
      amount,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    };
    setWaterIntake(newIntake);
    setEntries([...entries, newEntry]);
    saveData(newIntake, [...entries, newEntry]);
  };

  const addCustomAmount = () => {
    const amount = parseInt(customAmount);
    if (amount > 0) {
      addWater(amount);
      setCustomAmount('');
    }
  };

  const removeEntry = (id) => {
    const entry = entries.find(e => e.id === id);
    const newIntake = waterIntake - entry.amount;
    const newEntries = entries.filter(e => e.id !== id);
    setWaterIntake(newIntake);
    setEntries(newEntries);
    saveData(newIntake, newEntries);
  };

  const resetDay = () => {
    setWaterIntake(0);
    setEntries([]);
    saveData(0, []);
  };

  const percentage = Math.min((waterIntake / DAILY_GOAL) * 100, 100);
  const remaining = Math.max(DAILY_GOAL - waterIntake, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 p-6">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Droplet className="w-8 h-8 text-blue-500" />
            <h1 className="text-3xl font-bold text-gray-800">Water Intake</h1>
          </div>
          <p className="text-gray-600">{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</p>
        </div>

        {/* Progress Circle */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="relative w-40 h-40 mx-auto mb-6">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
              {/* Background circle */}
              <circle cx="60" cy="60" r="54" fill="none" stroke="#e5e7eb" strokeWidth="8" />
              {/* Progress circle */}
              <circle
                cx="60"
                cy="60"
                r="54"
                fill="none"
                stroke="#3b82f6"
                strokeWidth="8"
                strokeDasharray={`${(percentage / 100) * 339.29} 339.29`}
                strokeLinecap="round"
                style={{ transition: 'stroke-dasharray 0.3s ease' }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-3xl font-bold text-gray-800">{waterIntake}</div>
              <div className="text-sm text-gray-600">ml</div>
              <div className="text-xs text-gray-500 mt-1">{Math.round(percentage)}%</div>
            </div>
          </div>

          {/* Stats */}
          <div className="space-y-2 text-center">
            <div className="text-gray-700">
              <span className="font-semibold">{remaining} ml</span> to reach goal
            </div>
            <div className="text-sm text-gray-500">Daily goal: {DAILY_GOAL} ml</div>
            {waterIntake >= DAILY_GOAL && (
              <div className="text-green-600 font-semibold text-sm">🎉 Goal reached!</div>
            )}
          </div>
        </div>

        {/* Quick Add Buttons */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="grid grid-cols-3 gap-3 mb-4">
            <button
              onClick={() => addWater(250)}
              className="flex flex-col items-center gap-1 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition text-blue-600 font-semibold text-sm"
            >
              <Plus className="w-5 h-5" />
              250 ml
            </button>
            <button
              onClick={() => addWater(500)}
              className="flex flex-col items-center gap-1 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition text-blue-600 font-semibold text-sm"
            >
              <Plus className="w-5 h-5" />
              500 ml
            </button>
            <button
              onClick={() => addWater(1000)}
              className="flex flex-col items-center gap-1 p-3 rounded-lg bg-blue-50 hover:bg-blue-100 transition text-blue-600 font-semibold text-sm"
            >
              <Plus className="w-5 h-5" />
              1 L
            </button>
          </div>

          {/* Custom Amount */}
          <div className="flex gap-2">
            <input
              type="number"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              placeholder="Custom (ml)"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              onClick={addCustomAmount}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition font-semibold"
            >
              Add
            </button>
          </div>
        </div>

        {/* Entries Log */}
        {entries.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <h2 className="font-semibold text-gray-800 mb-4">Today's Log</h2>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {entries.map((entry) => (
                <div key={entry.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                  <div className="flex items-center gap-3 flex-1">
                    <Droplet className="w-4 h-4 text-blue-500" />
                    <div>
                      <div className="font-semibold text-gray-800">{entry.amount} ml</div>
                      <div className="text-xs text-gray-500">{entry.time}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => removeEntry(entry.id)}
                    className="text-gray-400 hover:text-red-500 transition"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reset Button */}
        <button
          onClick={resetDay}
          className="w-full flex items-center justify-center gap-2 p-3 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition"
        >
          <RotateCcw className="w-4 h-4" />
          Reset Today
        </button>
      </div>
    </div>
  );
}
