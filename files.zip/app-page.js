'use client';

import WaterTracker from '@/components/WaterTracker';

export default function Home() {
  return (
    <main>
      <WaterTracker />
    </main>
  );
}
