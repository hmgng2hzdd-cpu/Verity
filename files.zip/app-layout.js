import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Water Intake Tracker',
  description: 'Track your daily water intake and reach your hydration goals',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
