# Water Intake Tracker

A simple, beautiful web app to track your daily water intake and reach your hydration goals.

## Features

- ✨ Clean, modern UI with real-time progress tracking
- 💾 Persistent storage using browser localStorage
- ⚡ Quick-add buttons for common amounts (250ml, 500ml, 1L)
- 🎯 Visual progress circle showing daily goal completion
- 📱 Fully responsive design
- 🔄 Reset daily tracker at midnight automatically

## Tech Stack

- **Next.js 14** - React framework for production
- **React 18** - UI library
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Beautiful, consistent icons

## Getting Started

### Prerequisites
- Node.js 18+ installed on your machine
- npm or yarn package manager

### Local Development

1. Clone the repository:
```bash
git clone https://github.com/hmgng2hzdd-cpu/Website.git
cd Website
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
.
├── app/
│   ├── page.js           # Main page
│   ├── layout.js         # Root layout
│   └── globals.css       # Global styles
├── components/
│   └── WaterTracker.jsx  # Main tracker component
├── package.json          # Dependencies and scripts
├── tailwind.config.js    # Tailwind configuration
├── postcss.config.js     # PostCSS configuration
└── README.md             # This file
```

## Deployment to Vercel

### Option 1: Automatic Deployment (Recommended)

Since you already have Vercel connected to GitHub:

1. Rename the files in the correct directory structure:
   - Rename `app-page.js` → `page.js` in `app/` folder
   - Rename `app-layout.js` → `layout.js` in `app/` folder
   - Move `water-tracker.jsx` to `components/WaterTracker.jsx`

2. Push to GitHub:
```bash
git add .
git commit -m "Add water intake tracker"
git push origin main
```

3. Vercel will automatically detect changes and deploy!

### Option 2: Manual Deployment via Vercel CLI

```bash
npm install -g vercel
vercel
```

Follow the prompts to connect your project.

## Usage

1. **Add Water**: Click preset buttons or enter a custom amount
2. **Track Progress**: Watch the circular progress indicator fill as you drink
3. **View History**: See all entries for the day with timestamps
4. **Remove Entry**: Click the minus icon to remove incorrect entries
5. **Reset**: Use the reset button to start fresh (or wait for midnight)

## Customization

### Change Daily Goal
Edit `components/WaterTracker.jsx`:
```javascript
const DAILY_GOAL = 2000; // Change this value (in ml)
```

### Add More Quick Buttons
Add buttons in the grid section with:
```jsx
<button onClick={() => addWater(AMOUNT)}>
  {AMOUNT} ml
</button>
```

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers

## Data Storage

- All data is stored locally in your browser using localStorage
- Data persists across browser sessions
- Automatically resets daily

## License

This project is open source and available under the MIT License.

## Support

For issues or suggestions, create an issue in the GitHub repository.
